from django.apps import AppConfig


class WebfrontConfig(AppConfig):
    name = 'WebFront'